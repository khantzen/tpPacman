/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tp_pacman_kevin_hantzen_a2;

/**
 *
 * @author Kevin
 */
public enum Direction {
    TO_THE_TOP,
    TO_THE_RIGHT,
    TO_THE_BOT,
    TO_THE_LEFT;
}
