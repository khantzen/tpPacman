/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tp_pacman_kevin_hantzen_a2;

/**
 *
 * @author Kevin
 */
public interface Constant {
    /*
    *Max column number
    */
    public final static int COLUMN_NUMBER_MAX = 21;
    
    /*
    *Max line number
    */
    public final static int LINE_NUMBER_MAX = 21;
    
    /*
    * Square pixel size
    */
    
    public final static int SQUARE_PIXEL_SIZE = 30;
}
